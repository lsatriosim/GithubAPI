package com.example.githubapi

import android.support.v7.widget.RecyclerView
import android.support.v7.widget.RecyclerView.Recycler
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

class UserAdapter(private val listUser: ArrayList<String>) : RecyclerView.Adapter<UserAdapter.ViewHolder>() {
    class ViewHolder (view : View) : RecyclerView.ViewHolder(view) {

    }

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int): UserAdapter.ViewHolder {
        val view = LayoutInflater.from(viewGroup.context).inflate(R.layout.item_user, viewGroup, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(viewHolder: UserAdapter.ViewHolder, position: Int) {
        viewHolder.
    }

    override fun getItemCount(): Int {
        return listUser.size
    }
}